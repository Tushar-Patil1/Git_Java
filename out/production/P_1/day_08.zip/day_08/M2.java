package day_08;

public class M2 {
    public static void main(String[] args) {

        int a=100;
        Integer i = a; // Auto-boxing
        System.out.println(a);
        System.out.println(i);

        }
    }
