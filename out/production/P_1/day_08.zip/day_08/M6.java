package day_08;

public class M6 {

    public static void main(String[] args) {

        String str = "55";
        Integer a= Integer.valueOf(str); // It return object of value to Integer Class
        Integer b = Integer.parseInt(str); // Converts String type to primitive data type
        System.out.println(str);
        System.out.println(a);
        System.out.println(b);

    }

}
